
while True:
    commandinhome = input('~$ (Home)')

    if commandinhome == 'exit':
        break

    if commandinhome == 'help':
        print("cd [target location] example of target location: Documents,Downloads,ect.")
        print("ls: opens slected folder you are in Example: ~$(Downloads) ls ")
        print('ping: this command does not work yet')


    if commandinhome == 'ping 0.0.0.0':
        if commandinhome == 'ping 0.0.0.0':
            print("0.0.0.0 is up")

    if commandinhome == 'ping 1.1.1.1':
        if commandinhome == 'ping 1.1.1.1':
            print("1.1.1.1 is up")

    if commandinhome == 'ping 2.2.2.2':
        if commandinhome == 'ping 2.2.2.2':
            print("2.2.2.2 is up")

    if commandinhome == 'ping 3.3.3.3':
        if commandinhome == 'ping 3.3.3.3':
            print("3.3.3.3 is up")

    if commandinhome == 'ping 4.4.4.4':
        if commandinhome == 'ping 4.4.4.4':
            print("4.4.4.4 is up")

    if commandinhome == 'ping 5.5.5.5':
        if commandinhome == 'ping 5.5.5.5':
            print("5.5.5.5 is up")

    if commandinhome == 'ping 6.6.6.6':
        if commandinhome == 'ping 6.6.6.6':
            print("6.6.6.6 is up")

    if commandinhome == 'ping 7.7.7.7':
        if commandinhome == 'ping 7.7.7.7':
            print("7.7.7.7 is up")

    if commandinhome == 'ping 8.8.8.8':
        if commandinhome == 'ping 8.8.8.8':
            print("8.8.8.8 is up")

    if commandinhome == 'ping 9.9.9.9':
        if commandinhome == 'ping 9.9.9.9':
            print("9.9.9.9 is up")

    if commandinhome == 'ping 10.10.10.10':
        if commandinhome == 'ping 10.10.10.10':
            print("10.10.10.10 is up")


    if commandinhome == 'ls':
        print("Documents")
        print('Downloads')
        print('Misk')
        print('work in progress')

    if commandinhome == "cd":
        print("error 'cd [target location]'")

    if commandinhome == "cd Documents":
        command_inCD_documents = input("~$ (Documents)")

        if command_inCD_documents == 'cd random test1':
            print("this is test 1")
        if command_inCD_documents == 'cd random test2':
            print("this is test 2")
        if command_inCD_documents == 'cd random test3':
            print("this is test 3")
        if command_inCD_documents == 'cd random test4':
            print("this is test 4")

        if command_inCD_documents == 'ls':
            print("random test1")

            print("random test2")

            print("random test3")

            print("random test4")

    if commandinhome == "cd Downloads":

        command_inCD_downloads = input("~$ (Downloads)")
        if command_inCD_downloads == 'cd random test1 down':
            print("this is test 1 down")
        if command_inCD_downloads == 'cd random test2 down':
            print("this is test 2 down")
        if command_inCD_downloads == 'cd random test3 down':
            print("this is test 3 down")
        if command_inCD_downloads == 'cd random test4 down':
            print("this is test 4 down")

        if command_inCD_downloads == 'ls':
            print("random test1 down")

            print("random test2 down")

            print("random test3 down")

            print("random test4 down")

    if commandinhome == "cd Misk":
        command_inCD_misk = input("~$ (Misk)")

        if command_inCD_misk == 'cd random test1 misk':
            print("this is test 1 misk")
        if command_inCD_misk == 'cd random test2 misk':
            print("this is test 2 misk")
        if command_inCD_misk == 'cd random test3 misk':
            print("this is test 3 misk")
        if command_inCD_misk == 'cd random test4 misk':
            print("this is test 4 misk")

        if command_inCD_misk == 'ls':
            print("random test1 misk")

            print("random test2 misk")

            print("random test3 misk")

            print("random test4 misk")
