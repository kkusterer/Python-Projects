num = input("pick a number")
if num == "2" :
    print ("blake is cool")

else:
    print("you die")
