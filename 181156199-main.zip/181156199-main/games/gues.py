

def all():
    while True:
        print("I know if your number is even or not and more info")
        num = input("pick a number")
        try:
            if int(num) % 2 != 0:
                print(f"Your number is {num} and it is odd!")
            else:
                print(f"Your number is {num} and it is even!")
        except Exception as e:
            print(f"Encoutnered an error: {e}")


if __name__ == "__main__":
    all()
