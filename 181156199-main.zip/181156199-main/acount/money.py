def money():
    money = input("1 courent money,2 get more money")

    if money == '1':
                print(f"you have 0")

    if money == '2':
                add = input("how much money do you want to add")
                addmoney = int(add) + 0

    money2 = input("1 courent money,2 get more money")
    if money2 == "1":
                print(f"you have ${addmoney}")

    money()
