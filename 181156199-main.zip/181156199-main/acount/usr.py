def user ():
    name2 = input("what is your new username")
    print(f'Welcome, {name2}')

