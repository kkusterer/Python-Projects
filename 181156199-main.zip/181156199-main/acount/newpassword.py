def newpassword():
    newpas = input("what is your new pass")
    print(f"your new pass is {newpas}")
