def menu():
    opc = input("1 reset usr name, 2 reset pass, 3 acount ballence")
menu
