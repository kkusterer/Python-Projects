def k_to_fahrenheit(k):
    return ((k -  273.15) * 9/5 + 32)

choice = input("Choose an option (1,): ")

if choice == '1':
        k = float(input("Enter temperature in k: "))
        fahrenheit = k_to_fahrenheit(k)
        print(f"{k}°C is {fahrenheit}°F")

