num = input("pick Num")
print(f"num")
