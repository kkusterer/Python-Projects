name = input("what is your name")
print(f"Hello, {name}")
print(" my name is AI kinda ")

