num = input("pick a number")
x = num
sum = int(x) + 1

if sum == '2':
    print("x is 2")
